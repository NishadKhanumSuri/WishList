var DOM_Elements = {
    txtBox: {
        emailId: document.querySelector("#email"),
        pswrd: document.querySelector('#pswrd')
    },
    form: document.querySelector("form"),
    submitbtn: document.querySelector("#submitbtn"),
    validationMsgArr: document.querySelector(".validationMsg")
}
//validation part

DOM_Elements.form.onsubmit = validateMandatoryFields;
DOM_Elements.txtBox.emailId.addEventListener("keypress", nameValidateKeys);
DOM_Elements.txtBox.emailId.addEventListener("focusout", hideValidateMsg)

function nameValidateKeys() {
    var txtBox = this,
        keyCode = event.keyCode,
        validationMsg = txtBox.nextElementSibling,
        invalidChar = false,
        preventDefault = false;

    if ((keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode > 122) && (isNaN(event.key)) && keyCode !== 46 && keyCode !== 64) {
        invalidChar = true;
        preventDefault = true;
    }

    if (invalidChar) {  // if invalidChar is "true"---> msg will be visible to the user.
        validationMsg.style.visibility = "visible";
    }
    preventDefault && event.preventDefault();  //if preventDefault is true,(means, if the given vlu is true) 
}
function hideValidateMsg() {
    var current = this;
    DOM_Elements.validationMsgArr.style.visibility = "hidden";
}

//vadidation for login and registered user, to prevent entering to the next page if the login email or password is wrong...

function validateMandatoryFields() {
    if (!(DOM_Elements.txtBox.emailId.value && DOM_Elements.txtBox.pswrd.value)) {
        alert("Please Fill all the fields !");
        return false;
    }
    var isValidUser = isUserValid();
    if (!isValidUser) {
        return false;
    }
    localStorage.setItem("logined_user", DOM_Elements.txtBox.emailId.value);
}

function isUserValid() {
    var register_user = JSON.parse(localStorage.getItem("register_user")) || [],
        emailId = DOM_Elements.txtBox.emailId.value,
        password = DOM_Elements.txtBox.pswrd.value,
        isValid = false;
    if (register_user.length > 0) {
        register_user.forEach(function (user) {  //user is a variable, same as i which we used in for
            if (user.email === emailId) {
                if (password !== user.password) {
                    alert("you have entered wrong password!");
                } else {
                    isValid = true;
                }
            }
        });
    }
    return isValid;
}