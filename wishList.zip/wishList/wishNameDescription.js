var DOM_Elements = {
    headerName: {
        welcomeHeading: document.querySelector("h2"),
    },
    itemDetails: {
        wishItemName: document.querySelector("#wishItemName"),
        wishItemDesc: document.querySelector("#wishItemDescription"),
        wishItemLink: document.querySelector("#wishItemLink"),

        wishStatusfull: document.querySelector("#wishStatusfull"),
        wishStatusNotYet: document.querySelector("#wishStatusNotYet"),
        modalbox: $("#targetModal"),
    },
    btn: {
        saveBtn: document.querySelector("#savebtn"),
    },
    SelectWishName: localStorage.getItem("selectedWish"),
};

DOM_Elements.btn.saveBtn.addEventListener("click", save);

WelcomeMsg();
showTable();

function WelcomeMsg() {
    var emailId = localStorage.getItem("logined_user"),
        usersDetails = JSON.parse(localStorage.getItem("register_user")),
        userName;
    usersDetails.forEach(function (user) {
        if (user.email === emailId) {
            userName = user.name;
        }
    });
    DOM_Elements.headerName.welcomeHeading.innerHTML += " " + userName;
}

var index;
function addWishItems() {
    var newItem = {
        wishItemName: DOM_Elements.itemDetails.wishItemName.value,
        wishItemDesc: DOM_Elements.itemDetails.wishItemDesc.value,
        wishItemLink: DOM_Elements.itemDetails.wishItemLink.value,
        wishStatus: DOM_Elements.itemDetails.wishStatusfull.checked ? "Full filled" : "Not yet"
    },

        emailId = localStorage.getItem("logined_user"),
        userDetails = JSON.parse(localStorage.getItem("register_user")),
        user,
        wishIndex;

    for (var i = 0; i < userDetails.length; i++) {
        if (userDetails[i].email === emailId) {
            user = i;
        }
    }

    for (var i = 0; i < userDetails[user].wishList.length; i++) {
        if (userDetails[user].wishList[i].wishName === DOM_Elements.SelectWishName) {
            wishIndex = i;
        }
    }

    userDetails[user].wishList[wishIndex].itemList.push(newItem);
    localStorage.setItem("register_user", JSON.stringify(userDetails));
}

function save() {
    var wishItemName = DOM_Elements.itemDetails.wishItemName.value,
        wishItemDesc = DOM_Elements.itemDetails.wishItemDesc.value,
        wishItemLink = DOM_Elements.itemDetails.wishItemLink.value;

    if (wishItemName && wishItemDesc && wishItemLink) {

        addWishItems();
        DOM_Elements.itemDetails.modalbox.modal("hide");
        showTable();
    }
    else {
        alert("please fill all the feilds!!!")
    }
    DOM_Elements.itemDetails.wishItemName.value = "";
    DOM_Elements.itemDetails.wishItemDesc.value = "";
    DOM_Elements.itemDetails.wishItemLink.value = "";
}


function showTable() {
    var registerDetails = JSON.parse(localStorage.getItem("register_user")),
        loginedUser = localStorage.getItem("logined_user"),
        user;
    for (var i = 0; i < registerDetails.length; i++) {
        if (registerDetails[i].email === loginedUser) {
            user = i;
        }
    }

    for (var i = 0; i < registerDetails[user].wishList.length; i++) {
        if (registerDetails[user].wishList[i].wishName === DOM_Elements.SelectWishName) {
            wishIndex = i;
        }
    }

    if (registerDetails[user].wishList[wishIndex].itemList.length > 0) {
        document.querySelector("#createTable").style.visibility = "visible";
        table = "<table class='container table table-striped' style='width:70%;'>";
        table += `<caption><a href="welcometoWishList.html">${DOM_Elements.SelectWishName} Items</a></caption>`
        table += "<tr><th>Name</th><th>Description</th><th>Link</th><th>Status</th><th>Edit</th></tr>";

        registerDetails[user].wishList[wishIndex].itemList.forEach(wishItem => {
            table += `<tr><td>${wishItem.wishItemName}</td>
                        <td>${wishItem.wishItemDesc}</td>
                        <td><a href="${wishItem.wishItemLink}">Buy</a></td>
                         <td>${wishItem.wishStatus}</td> 
                        <td colspan="2">
                            <input type="button" id="editbtn" value="Edit" onclick="editWish(this)"> 
                            <input type="button" id="delbtn" value="Delete" onclick="deleteWish(this)" class="delbtn">
                        </td></tr>`
        })
        table += "</table>"
        document.querySelector("#createTable").innerHTML = table;
    }
    else {
        document.querySelector("#createTable").style.visibility = "hidden";
    }
}

function deleteWish(_this) {
    var index = Number(_this.parentElement.parentElement.rowIndex) - 1,
        registerDetails = JSON.parse(localStorage.getItem("register_user")),
        loginedUser = localStorage.getItem("logined_user"),
        user;
    wishIndex;

    for (var i = 0; i < registerDetails.length; i++) {
        if (registerDetails[i].email === loginedUser) {
            user = i;
        }
    }
    for (var i = 0; i < registerDetails[user].wishList.length; i++) {
        if (registerDetails[user].wishList[i].wishName === DOM_Elements.SelectWishName) {
            wishIndex = i;
        }
    }

    bootbox.confirm({
        size: 'small',
        message: "Are you sure?",
        callback: function (result) {
            if (result) {
                registerDetails[user].wishList[wishIndex].itemList.splice(index, 1);
                localStorage.setItem("register_user", JSON.stringify(registerDetails));
                showTable();
            }
        }
    });
}

function editWish(_this) {
    index = Number(_this.parentElement.parentElement.rowIndex) - 1; //index =itemIndex 
    var registerDetails = JSON.parse(localStorage.getItem("register_user")),
        loginedUser = localStorage.getItem("logined_user"),
        user;

    for (var i = 0; i < registerDetails.length; i++) {
        if (registerDetails[i].email === loginedUser) {
            user = i;
        }
    }

    for (var i = 0; i < registerDetails[user].wishList.length; i++) {
        if (registerDetails[user].wishList[i].wishName === DOM_Elements.SelectWishName) {
            wishIndex = i;
        }
    }
    DOM_Elements.itemDetails.wishItemName.value = registerDetails[user].wishList[wishIndex].itemList[index].wishItemName;
    DOM_Elements.itemDetails.wishItemDesc.value = registerDetails[user].wishList[wishIndex].itemList[index].wishItemDesc;
    DOM_Elements.itemDetails.wishItemLink.value = registerDetails[user].wishList[wishIndex].itemList[index].wishItemLink;
    DOM_Elements.itemDetails.wishStatusfull.checked ? "Full filled" : "Not yet";

    DOM_Elements.itemDetails.modalbox.modal('show');

    DOM_Elements.btn.saveBtn.removeEventListener("click", save);
    DOM_Elements.btn.saveBtn.value = "update";
    DOM_Elements.btn.saveBtn.addEventListener("click", function () { updateWish(registerDetails, user, wishIndex, index) });

    //anonymous funtion is created, bcz we cant pass the parameter function in the addEventListener.
}

function updateWish(registerDetails, user, wishIndex, index) {// index=itemIndex
    var updatedObj = {
        wishItemName: DOM_Elements.itemDetails.wishItemName.value,
        wishItemDesc: DOM_Elements.itemDetails.wishItemDesc.value,
        wishItemLink: DOM_Elements.itemDetails.wishItemLink.value,
        wishStatus: DOM_Elements.itemDetails.wishStatusfull.checked ? "Full filled" : "Not yet",
    }
    if (updatedObj.wishItemName && updatedObj.wishItemDesc && updatedObj.wishItemLink) {
        registerDetails[user].wishList[wishIndex].itemList[index] = updatedObj;
        localStorage.setItem("register_user", JSON.stringify(registerDetails));

        showTable();
        DOM_Elements.btn.saveBtn.removeEventListener('click', function () { });
        DOM_Elements.btn.saveBtn.addEventListener('click', save);
        DOM_Elements.itemDetails.modalbox.modal('hide');
    }
    else {
        alert("please fill all the details!!!");
        return false;
    }

    /*    DOM_Elements.details.wishName.value = "";
       DOM_Elements.details.wishDescription.value = ""; */
}