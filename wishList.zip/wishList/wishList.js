
var DOM_Elements = {
    details: {
        wishName: document.querySelector("#wishName"),
        wishDescription: document.querySelector("#wishDescription"),
        savebtn: document.querySelector("#savebtn"),
        modalbox: $("#targetModal"),
    },
    welcomeHeading: document.querySelector("h2"),
};
DOM_Elements.details.savebtn.addEventListener("click", save);

WelcomeMsg();
showTable();
var index;
function addWishItems() {
    var newItem = {
        wishName: DOM_Elements.details.wishName.value,
        wishDesc: DOM_Elements.details.wishDescription.value,
        itemList: []
    },
        emailId = localStorage.getItem("logined_user"),
        userDetails = JSON.parse(localStorage.getItem("register_user")),
        user;

    for (var i = 0; i < userDetails.length; i++) {
        if (userDetails[i].email === emailId) {
            user = i;
        }
    }
    userDetails[user].wishList.push(newItem);
    localStorage.setItem("register_user", JSON.stringify(userDetails));
}

function save() {
    var wishName = DOM_Elements.details.wishName.value,
        wishDesc = DOM_Elements.details.wishDescription.value;

    if (wishName && wishDesc) {

        addWishItems();
        DOM_Elements.details.modalbox.modal("hide");
        showTable();
    }
    else {
        alert("please fill all the feilds!!!")
    }
    DOM_Elements.details.wishName.value = "";
    DOM_Elements.details.wishDescription.value = "";
}

//this the pointing to the current anchor tag, to save the link.
function saveWishName(_this) {
    localStorage.setItem("selectedWish", _this.innerText)
}

function showTable() {
    var registerDetails = JSON.parse(localStorage.getItem("register_user")),
        loginedUser = localStorage.getItem("logined_user"),
        user;
    for (var i = 0; i < registerDetails.length; i++) {
        if (registerDetails[i].email === loginedUser) {
            user = i;
        }
    }
    if (registerDetails[user].wishList.length > 0) {
        document.querySelector("#createTable").style.visibility = "visible";
        table = "<table class='container table table-striped' style='width:70%;'>";
        table += "<tr><th>wish Name</th><th>wish Description</th><th>Edit</th></tr>";

        registerDetails[user].wishList.forEach(wishItem => {
            table += `<tr><td><a href="wishNameDescription.html" onclick="saveWishName(this)">${wishItem.wishName}</a></td>
                        <td>${wishItem.wishDesc}</td>
                        <td colspan="2">
                            <input type="button" id="editbtn" value="Edit" onclick="editWish(this)"> 
                            <input type="button" id="delbtn" value="Delete" onclick="deleteWish(this)" class="delbtn">
                        </td></tr>`
        })
        table += "</table>"
        document.querySelector("#createTable").innerHTML = table;
    }
    else {
        document.querySelector("#createTable").style.visibility = "hidden";
    }
}

function deleteWish(_this) {
    var index = Number(_this.parentElement.parentElement.rowIndex) - 1,
        registerDetails = JSON.parse(localStorage.getItem("register_user")),
        loginedUser = localStorage.getItem("logined_user"),
        user;

    for (var i = 0; i < registerDetails.length; i++) {
        if (registerDetails[i].email === loginedUser) {
            user = i;
        }
    }

    bootbox.confirm({
        size: 'small',
        message: "Are you sure?",
        callback: function (result) {
            if (result) {
                registerDetails[user].wishList.splice(index, 1);
                localStorage.setItem("register_user", JSON.stringify(registerDetails));
                showTable();
            }
        }
    });
}

function editWish(_this) {
    index = Number(_this.parentElement.parentElement.rowIndex) - 1;
    var registerDetails = JSON.parse(localStorage.getItem("register_user")),
        loginedUser = localStorage.getItem("logined_user"),
        user;

    for (var i = 0; i < registerDetails.length; i++) {
        if (registerDetails[i].email === loginedUser) {
            user = i;
        }
    }

    DOM_Elements.details.wishName.value = registerDetails[user].wishList[index].wishName;
    DOM_Elements.details.wishDescription.value = registerDetails[user].wishList[index].wishDesc;
    DOM_Elements.details.modalbox.modal('show');
    DOM_Elements.details.savebtn.removeEventListener("click", save);
    DOM_Elements.details.savebtn.value = "update";
    DOM_Elements.details.savebtn.addEventListener("click", function () { updateWish(registerDetails, user, index) });
}

function updateWish(registerDetails, user, index) {
    var updatedObj = {
        wishName: DOM_Elements.details.wishName.value,
        wishDesc: DOM_Elements.details.wishDescription.value,
        itemList: registerDetails[user].wishList[index].itemList
    }
    var registerDetails = JSON.parse(localStorage.getItem("register_user")),
        loginedUser = localStorage.getItem("logined_user"),
        user;

    for (var i = 0; i < registerDetails.length; i++) {
        if (registerDetails[i].email === loginedUser) {
            user = i;
        }
    }

    /*   if (!(updatedObj.wishName) || !(updatedObj.wishDesc)) {  
          alert("please fill all the details!!!");
          return false;
      } */

    if (updatedObj.wishName && updatedObj.wishDesc) {
        registerDetails[user].wishList[index] = updatedObj;
        localStorage.setItem("register_user", JSON.stringify(registerDetails));

        showTable();
        DOM_Elements.details.savebtn.removeEventListener('click', function () { });
        DOM_Elements.details.savebtn.addEventListener('click', save);
        DOM_Elements.details.modalbox.modal('hide');
    }
}

// Logic Layer

function WelcomeMsg() {
    var emailId = localStorage.getItem("logined_user"),
        usersDetails = JSON.parse(localStorage.getItem("register_user")),
        userName;
    usersDetails.forEach(function (user) {
        if (user.email === emailId) {
            userName = user.name;
        }
    });
    DOM_Elements.welcomeHeading.innerHTML += " " + userName;
}

$(document).ready(function () {
    isValid = $("#form").validate({
        debug: true,
        rules: {
            wishName: { required: true },
            wishDescription: { required: true },
        },
        messages: {
            wishName: { required: "wish Name can not be empty" },
            wishDescription: { required: "wish Description can not be empty" },
        }
    });
});

