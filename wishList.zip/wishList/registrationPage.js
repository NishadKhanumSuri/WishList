var DOM_Elements = {
    txtBox: {
        name: document.querySelector("#name"),
        emailId: document.querySelector("#email"),
        pswrd: document.querySelector("#pswrd"),
    },
    form: document.querySelector("form"),
    validationMsgArr: document.querySelectorAll(".validationMsg")
}
//validation part

for (vlu in DOM_Elements.txtBox) {
    DOM_Elements.txtBox[vlu].addEventListener("keypress", nameValidateKeys);
    DOM_Elements.txtBox[vlu].addEventListener("focusout", hideValidateMsg)
}
function nameValidateKeys() {
    var txtBox = this,
        keyCode = event.keyCode,
        validationMsg = txtBox.nextElementSibling,
        invalidChar = false,
        preventDefault = false;

    switch (txtBox) {
        case DOM_Elements.txtBox.name:
            if ((keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode > 122) && (keyCode !== 32 && keyCode !== 46)) {
                invalidChar = true;
                preventDefault = true;
            }
            break;
        case DOM_Elements.txtBox.emailId:
            if ((keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode > 122) && (isNaN(event.key)) && keyCode !== 46 && keyCode !== 64) {
                invalidChar = true;
                preventDefault = true;
            }
            break;
        case DOM_Elements.txtBox.pswrd:
            if ((keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode > 122) && (keyCode < 48 || keyCode > 57)) {
                invalidChar = true;
                preventDefault = true;
                break;
            }
            if (pswrd.value.length >= 8) {
                invalidChar = false;
                preventDefault = true;
            }
        default: break;
    }
    if (invalidChar) {  // if invalidChar is "true"---> msg will be visible to the user.
        validationMsg.style.visibility = "visible";
    }
    preventDefault && event.preventDefault();  //if preventDefault is true,(means, if the given vlu is true) 
}
function hideValidateMsg() {
    var current = this;
    DOM_Elements.validationMsgArr.forEach(function (vlu) {
        vlu.style.visibility = "hidden";
    });
    if (current === DOM_Elements.txtBox.pswrd) {
        validatePswrd(current);
    }
}
function validatePswrd(pswrd) {
    if (pswrd.value && pswrd.value.length !== 8) {
        pswrd.nextElementSibling.querySelector(".validationMsg").style.visibility = "visible";
        return false;
    }
    else {
        return true;
    }
}
function msg() {
    alert("registered successfully!");
}

function storeDate() {
  var   username = DOM_Elements.txtBox.name.value,
        Remail = DOM_Elements.txtBox.emailId.value,
        Rpassword = DOM_Elements.txtBox.pswrd.value

    user = {"name": username, "email": Remail, "password":Rpassword, "wishList":[] }
    user_Arr = []

    var local_users = localStorage.getItem("register_user")
    if(local_users){
        user_Arr = JSON.parse(local_users);
        user_Arr.push(user);
    }
    else{
        user_Arr.push(user);
    }
    localStorage.setItem("register_user", JSON.stringify(user_Arr));
}

