$(function(){
    alert("Hell")
    $("#form").validate({
        rules: {
            firstname: {required:true}
           
        },
        messages:{
            firstname: {required:"firstname can not be empty"}
        }
    });
}) 
